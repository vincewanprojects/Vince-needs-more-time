
import button
import pygame, sys
from settings import * 
from level import Level
from overworld import Overworld
from ui import UI
import os
import random
from game_data import levels
from support import import_folder
from decoration import Sky

import pygame
import sys

#1st cut scene
# Initialize pygame
pygame.init()
pygame.mixer.music.set_volume(0.3)
pygame.mixer.music.load("background_adventure_music.mp3")  
pygame.mixer.music.play(-1) 

# Set up display
screen_width, screen_height = 1200, 704
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Cutscene")

# Define colors
black = (0, 0, 0)
white = (100, 100, 100)
red = (255, 0, 0)
font = pygame.font.Font(None, 36)

# Load images for the cutscene
background_image1 = pygame.image.load("0cutscene2.jpeg") 
character_image = pygame.image.load("cutscene1.png")          

# Scale the ocean background image to fit the screen dimensions
beach_background = pygame.transform.scale(background_image1, (screen_width, screen_height))
character_image_bg = pygame.transform.scale(character_image, (1100, 500))

def cutscene():
    cutscene_text = [
        "An adventurer..a mercenary...a knight",
        "but was it wise choice to wander into the ghostly island of pirates..? ",
        "only time will tell...",
        "",
        "Press ENTER to continue..."
    ]

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                return  # Exit the cutscene

        screen.fill(black)  # Fill the screen with black background
        screen.blit(beach_background, (0, 0))
        screen.blit(character_image_bg, (-390, 200))

        y = 400
        for line in cutscene_text:
            text = font.render(line, True, white)
            text_rect = text.get_rect(center=(screen_width // 2, y))
            screen.blit(text, text_rect)
            y += 50

        pygame.display.flip()
        pygame.time.Clock().tick(30)

# Call the cutscene function
cutscene()


#attacking cutscene
# Load images for the cutscene
background_image1 = pygame.image.load("0cutscene2.jpeg") 
character_image = pygame.image.load("cutscene1.png")
monster_image = pygame.image.load("1cutscene1.png")  

# Scale the ocean background image to fit the screen dimensions
beach_background = pygame.transform.scale(background_image1, (screen_width, screen_height))
character_image_bg = pygame.transform.scale(character_image, (1100, 500))
monster_image_bg = pygame.transform.scale(monster_image, (300, 300))

def cutscene():
    cutscene_text = [
        "!!???? WHO ARE YOU!",
        "",
        "Press ENTER to continue..."
    ]

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                return  # Exit the cutscene

        screen.fill(black)  # Fill the screen with black background
        screen.blit(beach_background, (0, 0))
        screen.blit(character_image_bg, (-390, 200))
        screen.blit(monster_image_bg, (700, 400))

        y = 400
        for line in cutscene_text:
            text = font.render(line, True, red)
            text_rect = text.get_rect(center=(400, y))
            screen.blit(text, text_rect)
            y += 50

        pygame.display.flip()
        pygame.time.Clock().tick(30)

# Call the cutscene function
cutscene()

#recycling of code for another scene
def cutscene():
    cutscene_text = [
        "Doesn't matter...I'm still going to kill you!!",
        "",
        "Press ENTER to continue..."
    ]

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                return  # Exit the cutscene

        screen.fill(black)  # Fill the screen with black background
        screen.blit(beach_background, (0, 0))
        screen.blit(character_image_bg, (-390, 200))
        screen.blit(monster_image_bg, (500, 400))

        y = 400
        for line in cutscene_text:
            text = font.render(line, True, red)
            text_rect = text.get_rect(center=(400, y))
            screen.blit(text, text_rect)
            y += 50

        pygame.display.flip()
        pygame.time.Clock().tick(30)

# Call the cutscene function
cutscene()












# Load images for the cutscene
background_image = pygame.image.load("0cutscene2.jpeg") 
monster_image = pygame.image.load("1cutscene1.png")

# Initialize pygame
pygame.init()
screen = pygame.display.set_mode((screen_width, screen_height))

# Load images
background_image = pygame.image.load("0cutscene2.jpeg")
monster_image = pygame.image.load("1cutscene1.png")
knight_attack_frames = [pygame.image.load(f'img/Knight/Attack/{i}.png').convert_alpha() for i in range(8)]

# Scale images
background = pygame.transform.scale(background_image, (screen_width, screen_height))
monster = pygame.transform.scale(monster_image, (300, 300))
knight_attack_frames = [pygame.transform.scale(frame, (1100, 500)) for frame in knight_attack_frames]


attack_frame_index = 0
attack_animation_duration = len(knight_attack_frames)

# Set up animation timer
animation_timer = pygame.time.Clock()
animation_delay = 10  # Adjust this value for smoother animation

# Pygame setup
clock = pygame.time.Clock()
fps = 10

run = True
attack_started = False

counter = 0

while counter<8:
        

    clock.tick(fps)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Clear the screen
    screen.fill((0, 0, 0))

    # Display the background
    screen.blit(background, (0, 0))
    screen.blit(monster, (400, 400))

    # Display the knight's attack animation
    if attack_frame_index < attack_animation_duration:
        current_time = pygame.time.get_ticks()

        if not attack_started:
            attack_started = True
            pygame.time.set_timer(pygame.USEREVENT, animation_delay)

        if attack_started and current_time - animation_timer.get_time() > animation_delay:
            screen.blit(
                knight_attack_frames[attack_frame_index],
                (-390, 200),
            )
            attack_frame_index += 1
            animation_timer.tick()  # Reset the animation timer
        counter += 1
        print(counter)
    pygame.display.flip()
    screen.blit(character_image_bg, (-390, 200))




#warning cutscene
# Load images for the cutscene
background_image1 = pygame.image.load("warning.png")

# Scale the ocean background image to fit the screen dimensions
background = pygame.transform.scale(background_image1, (1000, 800))

def cutscene():
    cutscene_text = [
        "WARNING!!DO YOU WISH TO PROCEED?",
        "",
        "Press ENTER to continue..."
    ]

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                return  # Exit the cutscene

        screen.fill(black)  # Fill the screen with black background
        screen.blit(background, (100, 0))

        y = 400
        for line in cutscene_text:
            text = font.render(line, True, white)
            text_rect = text.get_rect(center=(screen_width // 2, y))
            screen.blit(text, text_rect)
            y += 50

        pygame.display.flip()
        pygame.time.Clock().tick(30)

# Call the cutscene function
cutscene()













#witness the might of the seas cut scene cut scene
background_image1 = pygame.image.load("cutscene2.png") 
character_image = pygame.image.load("cutscene1.png")
goddess_image1= pygame.image.load("cutscene3.png")  

# Scale the ocean background image to fit the screen dimensions
background = pygame.transform.scale(background_image1, (screen_width, screen_height))
character_image_bg = pygame.transform.scale(character_image, (700, 363))
goddess_image_bg = pygame.transform.scale(goddess_image1, (500, 500))


wave_sound = pygame.mixer.Sound("wave_sound.mp3")  #SOUND FILE OF WITNESS THE MIGHT OF THE SEAS
wave_sound.set_volume(10.0)
clock = pygame.time.Clock()

def cutscene():
    cutscene_text = [
        "YOU DARE ATTACK MY MINIONS! NOW DIE!!",
        "",
        "",
        "",
        ""
        
    ]

    start_time = pygame.time.get_ticks()  # Get the starting time
    waves_played = False

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                return  # Exit the cutscene

        current_time = pygame.time.get_ticks()  # Get the current time

        if not waves_played and current_time - start_time >= 300:  # Play waves after 0.3 seconds
            wave_sound.play()
            waves_played = True

        if current_time - start_time >= 1200:  # Display black screen for 3.5 seconds after waves
            screen.fill(black)  # Fill the screen with black background
            pygame.time.wait(2000)  # Wait for 2000 milliseconds
            return  # Exit the cutscene

        screen.fill(black)  # Fill the screen with black background
        screen.blit(background, (0, 0))
        screen.blit(character_image_bg, (-160, 300))
        screen.blit(goddess_image_bg, (800, 200))

        y = 400
        for line in cutscene_text:
            text = font.render(line, True, red)
            text_rect = text.get_rect(center=(screen_width // 2, y))
            screen.blit(text, text_rect)
            y += 50

        pygame.display.flip()
        clock.tick(30)

# Call the cutscene function
cutscene()




import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up display
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Adventure Start Cutscene")

# Colors
black = (0, 0, 0)
white = (255, 255, 255)

# Load font
font = pygame.font.Font(None, 60)
text = "This is where the adventure starts"
text_surface = font.render(text, True, white)
text_rect = text_surface.get_rect(center=(screen_width // 2, -text_surface.get_height() // 2))

# Load dungeon background image
dungeon_bg = pygame.image.load("dungeon_background.png")  # Replace with your dungeon background image path
dungeon_bg = pygame.transform.scale(dungeon_bg, (screen_width, screen_height))

# Cutscene variables
slide_speed = 1
slide_in = True
slide_out = False

# Cutscene loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
            running = False

    # Slide text in
    if slide_in and text_rect.centery < screen_height // 2:
        text_rect.centery += slide_speed
        if text_rect.centery >= screen_height // 2:
            slide_in = False
            slide_out = True

    # Clear the screen
    screen.fill(black)

    # Draw dungeon background
    screen.blit(dungeon_bg, (0, 0))

    # Draw text in fancy font
    screen.blit(text_surface, text_rect)

    # Slide text out
    if slide_out and text_rect.centery < screen_height + text_surface.get_height() // 2:
        text_rect.centery += slide_speed

    pygame.display.flip()

    # End the cutscene after text has slid out
    if slide_out and text_rect.centery >= screen_height + text_surface.get_height() // 2:
        running = False


#im aware i can optimise this but im running low on time pls understand









leveltrigger = 0
class Node(pygame.sprite.Sprite):
        def __init__(self,pos,status,icon_speed,path):
                super().__init__()
                self.frames = import_folder(path)
                self.frame_index = 0
                self.image = self.frames[self.frame_index]
                if status == 'available':
                        self.status = 'available'
                else:
                        self.status = 'locked'
                self.rect = self.image.get_rect(center = pos)

                self.detection_zone = pygame.Rect(self.rect.centerx-(icon_speed/2),self.rect.centery-(icon_speed/2),icon_speed,icon_speed)

        def animate(self):
                self.frame_index += 0.15
                if self.frame_index >= len(self.frames):
                        self.frame_index = 0
                self.image = self.frames[int(self.frame_index)]

        def update(self):
                if self.status == 'available':
                        self.animate()
                else:
                        tint_surf = self.image.copy()
                        tint_surf.fill('black',None,pygame.BLEND_RGBA_MULT)
                        self.image.blit(tint_surf,(0,0))

class Icon(pygame.sprite.Sprite):
        def __init__(self,pos):
                super().__init__()
                self.pos = pos
                self.image = pygame.image.load('../graphics/overworld/hat.png').convert_alpha()
                self.rect = self.image.get_rect(center = pos)

        def update(self):
                self.rect.center = self.pos

class Overworld:
        def __init__(self,start_level,max_level,surface,create_level):

                # setup 
                self.display_surface = surface 
                self.max_level = max_level
                self.current_level = start_level
                self.create_level = create_level

                # movement logic
                self.moving = False
                self.move_direction = pygame.math.Vector2(0,0)
                self.speed = 8

                # sprites 
                self.setup_nodes()
                self.setup_icon()
                self.sky = Sky(8,'overworld')

                # time 
                self.start_time = pygame.time.get_ticks()
                self.allow_input = False
                self.timer_length = 300

        def setup_nodes(self):
                self.nodes = pygame.sprite.Group()

                for index, node_data in enumerate(levels.values()):
                        if index <= self.max_level:
                                node_sprite = Node(node_data['node_pos'],'available',self.speed,node_data['node_graphics'])
                        else:
                                node_sprite = Node(node_data['node_pos'],'locked',self.speed,node_data['node_graphics'])
                        self.nodes.add(node_sprite)

        def draw_paths(self):
                if self.max_level > 0:
                        points = [node['node_pos'] for index,node in enumerate(levels.values()) if index <= self.max_level]
                        pygame.draw.lines(self.display_surface,'#a04f45',False,points,7)

        def setup_icon(self):
                self.icon = pygame.sprite.GroupSingle()
                icon_sprite = Icon(self.nodes.sprites()[self.current_level].rect.center)
                self.icon.add(icon_sprite)

        def input(self):
                keys = pygame.key.get_pressed()

                if not self.moving and self.allow_input:
                        if keys[pygame.K_RIGHT] and self.current_level < self.max_level:
                                self.move_direction = self.get_movement_data('next')
                                self.current_level += 1
                                self.moving = True
                        elif keys[pygame.K_LEFT] and self.current_level > 0:
                                self.move_direction = self.get_movement_data('previous')
                                self.current_level -= 1
                                self.moving = True
                        elif keys[pygame.K_SPACE]:
                                self.create_level(self.current_level)

        def get_movement_data(self,target):
                start = pygame.math.Vector2(self.nodes.sprites()[self.current_level].rect.center)
                
                if target == 'next': 
                        end = pygame.math.Vector2(self.nodes.sprites()[self.current_level + 1].rect.center)
                else:
                        end = pygame.math.Vector2(self.nodes.sprites()[self.current_level - 1].rect.center)

                return (end - start).normalize()

        def update_icon_pos(self):
                if self.moving and self.move_direction:
                        self.icon.sprite.pos += self.move_direction * self.speed
                        target_node = self.nodes.sprites()[self.current_level]
                        if target_node.detection_zone.collidepoint(self.icon.sprite.pos):
                                self.moving = False
                                self.move_direction = pygame.math.Vector2(0,0)

        def input_timer(self):
                if not self.allow_input:
                        current_time = pygame.time.get_ticks()
                        if current_time - self.start_time >= self.timer_length:
                                self.allow_input = True

        def run(self):
                global leveltrigger  # Declare leveltrigger as a global variable
                self.input_timer()
                self.input()
                self.update_icon_pos()
                self.icon.update()
                self.nodes.update()

                self.sky.draw(self.display_surface)
                self.draw_paths()
                self.nodes.draw(self.display_surface)
                self.icon.draw(self.display_surface)
                leveltrigger = self.current_level
class Game:
        def __init__(self):

                # game attributes
                self.max_level = 2
                self.max_health = 100
                self.cur_health = 100
                self.coins = 0
                
                # audio 
                self.level_bg_music = pygame.mixer.Sound('../audio/level_music.wav')
                self.overworld_bg_music = pygame.mixer.Sound('../audio/overworld_music.wav')

                # overworld creation
                self.overworld = Overworld(0,self.max_level,screen,self.create_level)
                self.status = 'overworld'
                self.overworld_bg_music.play(loops = -1)

                # user interface 
                self.ui = UI(screen)


        def create_level(self,current_level):
                self.level = Level(current_level,screen,self.create_overworld,self.change_coins,self.change_health)
                self.status = 'level'
                self.overworld_bg_music.stop()
                self.level_bg_music.play(loops = -1)

        def create_overworld(self,current_level,new_max_level):
                if new_max_level > self.max_level:
                        self.max_level = new_max_level
                self.overworld = Overworld(current_level,self.max_level,screen,self.create_level)
                self.status = 'overworld'
                self.overworld_bg_music.play(loops = -1)
                self.level_bg_music.stop()

        def change_coins(self,amount):
                self.coins += amount

        def change_health(self,amount):
                self.cur_health += amount

        def check_game_over(self):
                if self.cur_health <= 0:
                        self.cur_health = 100
                        self.coins = 0
                        self.max_level = 0
                        self.overworld = Overworld(0,self.max_level,screen,self.create_level)
                        self.status = 'overworld'
                        self.level_bg_music.stop()
                        self.overworld_bg_music.play(loops = -1)

        def run(self):
                if self.status == 'overworld':
                        self.overworld.run()
                else:
                        self.level.run()
                        self.ui.show_health(self.cur_health,self.max_health)
                        self.ui.show_coins(self.coins)
                        self.check_game_over()




pygame.init()

screen_width, screen_height = 1200, 704
screen = pygame.display.set_mode((screen_width, screen_height))

text_font = pygame.font.SysFont("Helvetica", 50)

# Load the background image
background_image = pygame.image.load("background.png")  
background_image = pygame.transform.scale(background_image, (screen_width, screen_height))  # Scale the image to fit the screen

# Function for outputting text onto the screen
def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))

run = True
start_time = pygame.time.get_ticks()  # Get the start time in milliseconds
duration_in_seconds = 5  # Set the duration in seconds

while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Calculate the elapsed time since the start of the program in seconds
    elapsed_time = (pygame.time.get_ticks() - start_time) / 1000

    # Check if 5 seconds have passed
    if elapsed_time >= duration_in_seconds:
        run = False

    # Blit the background image
    screen.blit(background_image, (0, 0))

    # Display the movement instructions
    white = (255, 255, 255)
    draw_text("Movement keys:", text_font, white, 500, 100)  
    draw_text("left_arrow_key = move to the left", text_font, white, 500, 150)   
    draw_text("right_arrow_key = move to the right", text_font, white, 500, 200)  
    draw_text("spacebar = jump", text_font, white, 500, 250)  

    pygame.display.flip()

pygame.quit()



# Pygame setup
pygame.init()
screen = pygame.display.set_mode((screen_width,screen_height))
clock = pygame.time.Clock()
game = Game()

while leveltrigger < 5:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                                
        
        screen.fill('grey')
        game.run()

        pygame.display.update()
        clock.tick(60)

# NOT ENOUGH TIME BUT WILL ADD CUT SCENES AND A SHOP BEFORE BOSS BATTLE STAY TUNED TO FIND OUT MORE!
print('honk')
print(leveltrigger)
#new sections for boss travel thru forest

pygame.init()

clock = pygame.time.Clock()
fps = 60

#game window
bottom_panel = 150
screen_width = 800
screen_height = 400 + bottom_panel

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Battle')


#define game variables
current_fighter = 1
total_fighters = 3
action_cooldown = 0
action_wait_time = 90
attack = False
potion = False
potion_effect = 15
clicked = False
game_over = 0


#define fonts
font = pygame.font.SysFont('Times New Roman', 26)

#define colours
red = (255, 0, 0)
green = (0, 255, 0)

#load images
#background image
background_img = pygame.image.load('img/Background/background1.png').convert_alpha()
#panel image
panel_img = pygame.image.load('img/Icons/panel.png').convert_alpha()
#button images
potion_img = pygame.image.load('img/Icons/potion.png').convert_alpha()
restart_img = pygame.image.load('img/Icons/restart.png').convert_alpha()
#load victory and defeat images
victory_img = pygame.image.load('img/Icons/victory.png').convert_alpha()
defeat_img = pygame.image.load('img/Icons/defeat.png').convert_alpha()
#sword image
sword_img = pygame.image.load('img/Icons/sword.png').convert_alpha()


#create function for drawing text
def draw_text(text, font, text_col, x, y):
	img = font.render(text, True, text_col)
	screen.blit(img, (x, y))


#function for drawing background
def draw_bg():
	screen.blit(background_img, (0, 0))


#function for drawing panel
def draw_panel():
	#draw panel rectangle
	screen.blit(panel_img, (0, screen_height - bottom_panel))
	#show knight stats
	draw_text(f'{knight.name} HP: {knight.hp}', font, red, 100, screen_height - bottom_panel + 10)
	for count, i in enumerate(bandit_list):
		#show name and health
		draw_text(f'{i.name} HP: {i.hp}', font, red, 550, (screen_height - bottom_panel + 10) + count * 60)




#fighter class
class Fighter():
	def __init__(self, x, y, name, max_hp, strength, potions):
		self.name = name
		self.max_hp = max_hp
		self.hp = max_hp
		self.strength = strength
		self.start_potions = potions
		self.potions = potions
		self.alive = True
		self.animation_list = []
		self.frame_index = 0
		self.action = 0#0:idle, 1:attack, 2:hurt, 3:dead
		self.update_time = pygame.time.get_ticks()
		#load idle images
		temp_list = []
		for i in range(8):
			img = pygame.image.load(f'img/{self.name}/Idle/{i}.png')
			img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
			temp_list.append(img)
		self.animation_list.append(temp_list)
		#load attack images
		temp_list = []
		for i in range(8):
			img = pygame.image.load(f'img/{self.name}/Attack/{i}.png')
			img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
			temp_list.append(img)
		self.animation_list.append(temp_list)
		#load hurt images
		temp_list = []
		for i in range(3):
			img = pygame.image.load(f'img/{self.name}/Hurt/{i}.png')
			img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
			temp_list.append(img)
		self.animation_list.append(temp_list)
		#load death images
		temp_list = []
		for i in range(10):
			img = pygame.image.load(f'img/{self.name}/Death/{i}.png')
			img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
			temp_list.append(img)
		self.animation_list.append(temp_list)
		self.image = self.animation_list[self.action][self.frame_index]
		self.rect = self.image.get_rect()
		self.rect.center = (x, y)


	def update(self):
		animation_cooldown = 100
		#handle animation
		#update image
		self.image = self.animation_list[self.action][self.frame_index]
		#check if enough time has passed since the last update
		if pygame.time.get_ticks() - self.update_time > animation_cooldown:
			self.update_time = pygame.time.get_ticks()
			self.frame_index += 1
		#if the animation has run out then reset back to the start
		if self.frame_index >= len(self.animation_list[self.action]):
			if self.action == 3:
				self.frame_index = len(self.animation_list[self.action]) - 1
			else:
				self.idle()


	
	def idle(self):
		#set variables to idle animation
		self.action = 0
		self.frame_index = 0
		self.update_time = pygame.time.get_ticks()


	def attack(self, target):
		#deal damage to enemy
		rand = random.randint(-5, 5)
		damage = self.strength + rand
		target.hp -= damage
		#run enemy hurt animation
		target.hurt()
		#check if target has died
		if target.hp < 1:
			target.hp = 0
			target.alive = False
			target.death()
		damage_text = DamageText(target.rect.centerx, target.rect.y, str(damage), red)
		damage_text_group.add(damage_text)
		#set variables to attack animation
		self.action = 1
		self.frame_index = 0
		self.update_time = pygame.time.get_ticks()

	def hurt(self):
		#set variables to hurt animation
		self.action = 2
		self.frame_index = 0
		self.update_time = pygame.time.get_ticks()

	def death(self):
		#set variables to death animation
		self.action = 3
		self.frame_index = 0
		self.update_time = pygame.time.get_ticks()


	def reset (self):
		self.alive = True
		self.potions = self.start_potions
		self.hp = self.max_hp
		self.frame_index = 0
		self.action = 0
		self.update_time = pygame.time.get_ticks()


	def draw(self):
		screen.blit(self.image, self.rect)



class HealthBar():
	def __init__(self, x, y, hp, max_hp):
		self.x = x
		self.y = y
		self.hp = hp
		self.max_hp = max_hp


	def draw(self, hp):
		#update with new health
		self.hp = hp
		#calculate health ratio
		ratio = self.hp / self.max_hp
		pygame.draw.rect(screen, red, (self.x, self.y, 150, 20))
		pygame.draw.rect(screen, green, (self.x, self.y, 150 * ratio, 20))



class DamageText(pygame.sprite.Sprite):
	def __init__(self, x, y, damage, colour):
		pygame.sprite.Sprite.__init__(self)
		self.image = font.render(damage, True, colour)
		self.rect = self.image.get_rect()
		self.rect.center = (x, y)
		self.counter = 0


	def update(self):
		#move damage text up
		self.rect.y -= 1
		#delete the text after a few seconds
		self.counter += 1
		if self.counter > 30:
			self.kill()



damage_text_group = pygame.sprite.Group()


knight = Fighter(200, 260, 'Knight', 20, 10, 3)
bandit1 = Fighter(550, 270, 'Bandit', 20, 6, 1)
bandit2 = Fighter(700, 270, 'Bandit', 20, 6, 1)

bandit_list = []
bandit_list.append(bandit1)
bandit_list.append(bandit2)

knight_health_bar = HealthBar(100, screen_height - bottom_panel + 40, knight.hp, knight.max_hp)
bandit1_health_bar = HealthBar(550, screen_height - bottom_panel + 40, bandit1.hp, bandit1.max_hp)
bandit2_health_bar = HealthBar(550, screen_height - bottom_panel + 100, bandit2.hp, bandit2.max_hp)

#create buttons
potion_button = button.Button(screen, 100, screen_height - bottom_panel + 70, potion_img, 64, 64)
restart_button = button.Button(screen, 330, 120, restart_img, 120, 30)

run = True
while run:

	clock.tick(fps)

	#draw background
	draw_bg()

	#draw panel
	draw_panel()
	knight_health_bar.draw(knight.hp)
	bandit1_health_bar.draw(bandit1.hp)
	bandit2_health_bar.draw(bandit2.hp)

	#draw fighters
	knight.update()
	knight.draw()
	for bandit in bandit_list:
		bandit.update()
		bandit.draw()

	#draw the damage text
	damage_text_group.update()
	damage_text_group.draw(screen)

	#control player actions
	#reset action variables
	attack = False
	potion = False
	target = None
	#make sure mouse is visible
	pygame.mouse.set_visible(True)
	pos = pygame.mouse.get_pos()
	for count, bandit in enumerate(bandit_list):
		if bandit.rect.collidepoint(pos):
			#hide mouse
			pygame.mouse.set_visible(False)
			#show sword in place of mouse cursor
			screen.blit(sword_img, pos)
			if clicked == True and bandit.alive == True:
				attack = True
				target = bandit_list[count]
	if potion_button.draw():
		potion = True
	#show number of potions remaining
	draw_text(str(knight.potions), font, red, 150, screen_height - bottom_panel + 70)


	if game_over == 0:
		#player action
		if knight.alive == True:
			if current_fighter == 1:
				action_cooldown += 1
				if action_cooldown >= action_wait_time:
					#look for player action
					#attack
					if attack == True and target != None:
						knight.attack(target)
						current_fighter += 1
						action_cooldown = 0
					#potion
					if potion == True:
						if knight.potions > 0:
							#check if the potion would heal the player beyond max health
							if knight.max_hp - knight.hp > potion_effect:
								heal_amount = potion_effect
							else:
								heal_amount = knight.max_hp - knight.hp
							knight.hp += heal_amount
							knight.potions -= 1
							damage_text = DamageText(knight.rect.centerx, knight.rect.y, str(heal_amount), green)
							damage_text_group.add(damage_text)
							current_fighter += 1
							action_cooldown = 0
		else:
			game_over = -1


		#enemy action
		for count, bandit in enumerate(bandit_list):
			if current_fighter == 2 + count:
				if bandit.alive == True:
					action_cooldown += 1
					if action_cooldown >= action_wait_time:
						#check if bandit needs to heal first
						if (bandit.hp / bandit.max_hp) < 0.5 and bandit.potions > 0:
							#check if the potion would heal the bandit beyond max health
							if bandit.max_hp - bandit.hp > potion_effect:
								heal_amount = potion_effect
							else:
								heal_amount = bandit.max_hp - bandit.hp
							bandit.hp += heal_amount
							bandit.potions -= 1
							damage_text = DamageText(bandit.rect.centerx, bandit.rect.y, str(heal_amount), green)
							damage_text_group.add(damage_text)
							current_fighter += 1
							action_cooldown = 0
						#attack
						else:
							bandit.attack(knight)
							current_fighter += 1
							action_cooldown = 0
				else:
					current_fighter += 1

		#if all fighters have had a turn then reset
		if current_fighter > total_fighters:
			current_fighter = 1


	#check if all bandits are dead
	alive_bandits = 0
	for bandit in bandit_list:
		if bandit.alive == True:
			alive_bandits += 1
	if alive_bandits == 0:
		game_over = 1


	#check if game is over
	if game_over != 0:
		if game_over == 1:
			screen.blit(victory_img, (250, 50))
		if game_over == -1:
			screen.blit(defeat_img, (290, 50))
		if restart_button.draw():
			knight.reset()
			for bandit in bandit_list:
				bandit.reset()
			current_fighter = 1
			action_cooldown
			game_over = 0



	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run = False
		if event.type == pygame.MOUSEBUTTONDOWN:
			clicked = True
		else:
			clicked = False

	pygame.display.update()

pygame.quit()
